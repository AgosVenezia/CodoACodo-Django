from setuptools import setup

setup(
    name="recursos humanos",
    version="0.1",
    description="Paquete de ejemplo de empleados y nómina",
    author="Agostina Venezia",
    author_email="agostina.cv@gmail.com",
    url="",
    packages= ["recursos_humanos","recursos_humanos.personal"],
    scripts=[]
)